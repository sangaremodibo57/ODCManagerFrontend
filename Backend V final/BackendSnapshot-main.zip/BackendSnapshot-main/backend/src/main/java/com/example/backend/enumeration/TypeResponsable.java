package com.example.backend.enumeration;

public enum TypeResponsable {
	Formateur, Intervenant;

}
