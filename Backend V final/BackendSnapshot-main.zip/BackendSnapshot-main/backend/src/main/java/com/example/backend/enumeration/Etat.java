package com.example.backend.enumeration;

public enum Etat {
    active, inactive, EnAttente
}
