package com.example.backend.enumeration;

public enum Statut {
	encours,terminer;

}
