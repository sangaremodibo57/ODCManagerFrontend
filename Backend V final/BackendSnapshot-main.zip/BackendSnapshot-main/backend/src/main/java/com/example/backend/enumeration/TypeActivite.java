package com.example.backend.enumeration;

public enum TypeActivite {
	Formation,Talk,Evenement
}
