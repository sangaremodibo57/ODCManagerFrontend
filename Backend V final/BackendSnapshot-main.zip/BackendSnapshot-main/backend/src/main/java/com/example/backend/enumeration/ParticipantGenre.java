package com.example.backend.enumeration;

public enum ParticipantGenre {
    Homme,
    Femme
}
